local players = require 'server.storage.players'

---@type StorageFunctions
return players