---@deprecated This file is deprecated and will be removed in the future.
---@return table<string, vector4>
return {}