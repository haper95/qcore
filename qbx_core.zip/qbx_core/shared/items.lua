---@deprecated This file is deprecated and will be removed in the future. Please add your items directly in ox_inventory/data/items.lua file. Currently items placed in here will be converted at next server restart.
---@type table<string, Item>
return {}