---@deprecated This file is deprecated and will be removed in the future. If you are utilizing QB-Core bridge functionality you will need to populate weapons here for them to be available in QBCore.Shared.Weapons. If not please add your weapons in ox_inventory/data/weapons.lua file. Currently weapons in this file will be converted on next server start.
---@type table<number, Weapon>
return {}